# WeatherWise Analytics — Weather Intelligence & Machine Learning Platform

**WeatherWise Analytics** is an enterprise-grade meteorological intelligence and machine learning platform built with **Streamlit** and powered by **MongoDB** with **PyMongo**, **Scikit-learn**, and **Pandas**.

The platform centralizes 73+ continuous years of historical Delhi daily meteorological observations (1951–2024, 26,803 records) into a high-performance MongoDB NoSQL document store, applies strictly leak-free chronological machine learning for next-day precipitation forecasting, predicts next-day maximum temperatures via regression, and translates model probabilities into actionable daily recommendations.

---

## 1. Executive Summary & Architecture

Unlike generic weather demonstration dashboards or uncalibrated classification prototypes, **WeatherWise Analytics** operates as an end-to-end, leak-free meteorological intelligence pipeline:

- **Persistent NoSQL Document Store**: Backed by local MongoDB Community Server with thread-safe PyMongo connection pooling (`serverSelectionTimeoutMS=3000`), unique chronological indexing, and zero-loss bulk upsert ingestion.
- **Anti-Leakage Feature Engineering**: Strict chronological boundary enforcement where features on day $t$ strictly predict outcomes on day $t+1$ ($\text{Rain}_{t+1}$ and $\text{TempMax}_{t+1}$), completely excluding current-day rain indicators, future values, and record IDs.
- **Multi-Model Classification Benchmarking**: Systematic empirical evaluation comparing **Logistic Regression**, **Decision Tree**, and **Random Forest** on an unseen 15-year chronological test period (2009–2024, 5,350 days).
- **Continuous Temperature Regression**: Real-time next-day maximum temperature prediction via Random Forest Regressor ($R^2 = 0.944$, $\text{MAE} = 1.18\ ^\circ\text{C}$).
- **Actionable Advisory Engine**: Dynamic rule-based decision support mapping statistical probabilities into umbrella advisories, thermal clothing guidance across 5 temperature categories, and outdoor activity feasibility ratings.
- **Resilient Offline Architecture**: Automatic detection of MongoDB connectivity status with an instant, graceful fallback to local CSV operations without application stalling or simulated states.

---

## 2. Project Directory Structure

```text
WeatherWise_Analytics/
├── app.py                       # Streamlit web application, multi-page router, and layout
├── config.py                    # Centralized system paths, database configs, and hyperparameters
├── requirements.txt             # Pinned Python package dependencies
├── README.md                    # Comprehensive technical & execution documentation
├── PROJECT_REPORT.md            # In-depth academic report and PyMongo architectural documentation
├── .gitignore                   # Git exclusion rules for environments, caches, and credentials
├── .env.example                 # Template configuration with placeholder values
├── .env                         # Active local environment settings (git-ignored)
├── assets/
│   ├── README.md                # Assets documentation
│   └── weather_overview.jpg     # Official weather intelligence illustration
├── data/
│   ├── README.md                # Schema details and data dictionaries
│   └── delhi_weather.csv        # Verified 26,803-record Delhi historical weather dataset
├── src/
│   ├── __init__.py              # Package initialization
│   ├── data_loader.py           # Ingestion, date parsing, cleaning, and quality audits
│   ├── mongodb_manager.py       # PyMongo pooling, unique indexing, and bulk upsert operations
│   ├── preprocessing.py         # Anti-leakage target construction and chronological splitting
│   ├── classification.py        # Logistic Regression, Decision Tree, and Random Forest pipelines
│   ├── regression.py            # Next-day maximum temperature regression pipelines
│   ├── evaluation.py            # Classification & regression metrics, ROC curve, and ranking
│   ├── visualizations.py        # Enterprise Plotly charts (ROC curves, heatmaps, bar charts)
│   ├── recommendations.py       # Rule-based weather advisories (umbrella, clothing, activity)
│   ├── report_generator.py      # Academic report generator for PDF and DOCX
│   ├── pipeline.py              # End-to-end execution script
│   └── utils.py                 # Safe numeric conversions, JSON encoders, and logging
├── models/
│   ├── .gitkeep
│   ├── logistic_regression.joblib  # Serialized Logistic Regression pipeline
│   ├── decision_tree.joblib        # Serialized Decision Tree classifier
│   ├── random_forest.joblib        # Serialized Random Forest classifier
│   └── random_forest_regressor.joblib # Serialized Random Forest regressor
├── outputs/
│   ├── .gitkeep
│   ├── README.md
│   ├── classification_metrics.json # Stored test evaluation metrics for all classifiers
│   ├── regression_metrics.json     # Stored test evaluation metrics for regressors
│   ├── model_comparison.csv        # Tabular benchmark comparison of all classifiers
│   ├── test_predictions_classification.csv # Test set predictions for data exploration
│   └── test_predictions_regression.csv     # Test set temperature predictions
├── reports/
│   ├── README.md
│   ├── project_report.pdf       # Formal academic project report in PDF format
│   └── project_report.docx      # Editable academic project report in Microsoft Word format
├── tests/
│   ├── __init__.py
│   ├── test_data_loader.py      # Schema verification, null checks, and date parsing tests
│   ├── test_preprocessing.py    # Target construction shift and anti-leakage ordering tests
│   ├── test_classification.py   # Classifier training, pipeline fitting, and inference tests
│   ├── test_regression.py       # Regressor training and continuous prediction sanity tests
│   ├── test_evaluation.py       # Evaluation metrics, ROC curve, and ranking logic tests
│   └── test_mongodb_manager.py  # Connection status, collection stats, and duplicate prevention tests
└── submission/
    ├── README.txt               # Submission instructions
    └── WeatherWise_Analytics_Submission.zip # Complete deliverable archive
```

---

## 3. Technology Stack & Prerequisites

- **Language**: Python 3.14 / 3.13 (64-bit)
- **Database Engine**: MongoDB Community Server 8.x / 7.x (local instance on port 27017)
- **Database Driver**: PyMongo 4.19.0+
- **Interactive UI**: Streamlit 1.30.0 - 1.58.0
- **Data & Computation**: Pandas 3.0.3+, NumPy 2.4.6+
- **Machine Learning**: Scikit-learn 1.9.1+
- **Interactive Visualizations**: Plotly 7.1.0+
- **Statistical Graphics**: Seaborn 0.13.2+, Matplotlib 3.11.2+
- **Model Serialization**: Joblib 1.6.0+
- **Document Generation**: ReportLab 5.0.0+, python-docx 1.2.0+
- **Test Suite**: pytest 9.1.1+

---

## 4. Quick Start & Execution Guide (Windows)

Follow these exact Windows PowerShell commands:

### Step 1: Open Project Directory
```powershell
cd "D:\subjects\year4_sem7\MongoDB\CA2Mongo\WeatherWise_Analytics"
```

### Step 2: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 3: Verify Environment Versions
```powershell
python -c "import pymongo, streamlit, pandas, sklearn; print('PyMongo:', pymongo.__version__, '| Streamlit:', streamlit.__version__, '| Pandas:', pandas.__version__, '| Scikit-learn:', sklearn.__version__)"
```

### Step 4: Run Automated Test Suite
```powershell
python -m pytest tests/ -v
```
*Expected result: 13 passed in ~8 seconds.*

### Step 5: (Optional) Re-train Models & Regenerate Artifacts
```powershell
python src/pipeline.py
```

### Step 6: Launch the WeatherWise Analytics Platform
```powershell
streamlit run app.py
```
*The platform will open automatically in your browser at `http://localhost:8501`.*

### Step 7: Stop the Application
Press `Ctrl + C` in the active terminal window to gracefully terminate the Streamlit server.

---

## 5. Machine Learning & Mathematical Workflow

### 1. Data Ingestion & Quality Auditing
- **Dataset Source:** Historical Delhi Daily Weather Dataset (`data/delhi_weather.csv`).
- **Volume:** 26,803 daily observations recorded continuously between **January 1, 1951** and **June 19, 2024** (73.5 years).
- **Integrity Validation:** 0 duplicate dates detected; only 55 rows (0.2%) contain missing entries.
- **Trace Rainfall Resolution:** Meteorological `'Tr'` entries (trace precipitation $< 0.1$ mm) are cleanly parsed to 0.05 mm for numeric consistency while assigning qualitative rain status (`Has_rained = 1`).

### 2. Anti-Leakage Feature Assembly
In time-series meteorological forecasting, random cross-validation shuffles future dates into the past, causing severe lookahead bias. WeatherWise Analytics enforces a strict lag architecture:
- Chronologically sort records by `Date_Parsed`.
- Features observed on day $t$:
  $$X(t) = [\text{Temp Max}_t, \text{Temp Min}_t, \text{Temp\_diff}_t, \text{Month}_t, \text{Day}_t, \text{Week}_t]$$
- Target predicted for day $t+1$:
  $$y_{\text{rain}}(t) = \text{Has\_rained\_Binary}(t+1) \in \{0, 1\}$$
  $$y_{\text{temp}}(t) = \text{Temp Max}(t+1) \in \mathbb{R}\ (^\circ\text{C})$$
- Current-day rain amount, qualitative rain outcome, and record identifiers ($\text{\_id}$) are strictly excluded from $X(t)$.

### 3. Chronological Train / Test Partitioning
- **Training Partition (80.0%):** 1951-01-01 to 2009-07-30 (21,396 continuous observations).
- **Test Partition (20.0%):** 2009-07-31 to 2024-06-18 (5,350 unseen future observations).
- Zero temporal overlap exists between training and evaluation partitions.

### 4. Classification Benchmark Across Candidate Models

All models were evaluated on the held-out test partition (5,350 days, with 960 actual rainy events and 4,390 dry days):

| Classifier Architecture | Test Accuracy | Precision | Recall (Sensitivity) | F1 Score | ROC-AUC | True Positives | False Negatives | False Positives | True Negatives |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Random Forest** | **0.7656** | **0.4186** | 0.7914 | **0.5476** | 0.8489 | 760 | 200 | 1,054 | 3,336 |
| **Decision Tree** | 0.7447 | 0.3976 | **0.8238** | 0.5363 | **0.8519** | **791** | **169** | 1,198 | 3,192 |
| **Logistic Regression** | 0.7275 | 0.3778 | 0.8040 | 0.5140 | 0.8407 | 772 | 188 | 1,271 | 3,119 |

#### Mathematical Metrics Defined:
- **Accuracy**: $\frac{TP + TN}{TP + TN + FP + FN}$
- **Precision**: $\frac{TP}{TP + FP}$
- **Recall (Sensitivity)**: $\frac{TP}{TP + FN}$
- **F1 Score**: $2 \cdot \frac{\text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}}$
- **ROC-AUC**: Integral of True Positive Rate ($TPR = \frac{TP}{P}$) against False Positive Rate ($FPR = \frac{FP}{N}$) across all classification thresholds.

### 5. Next-Day Maximum Temperature Regression Benchmark

Evaluated on the same chronological test period predicting tomorrow's maximum temperature:

| Regressor Architecture | Mean Absolute Error (MAE) | Root Mean Squared Error (RMSE) | Coefficient of Determination ($R^2$) |
|---|:---:|:---:|:---:|
| **Random Forest Regressor** | **1.18 °C** | **1.64 °C** | **0.9444** |
| **Decision Tree Regressor** | 1.21 °C | 1.67 °C | 0.9424 |
| **Linear Regression** | 1.20 °C | 1.68 °C | 0.9418 |

- **MAE**: $\frac{1}{n} \sum_{i=1}^n |y_i - \hat{y}_i|$
- **RMSE**: $\sqrt{\frac{1}{n} \sum_{i=1}^n (y_i - \hat{y}_i)^2}$
- **$R^2$ Score**: $1 - \frac{\sum (y_i - \hat{y}_i)^2}{\sum (y_i - \bar{y})^2}$

---

## 6. Application Views & Core Features

1. **Overview Dashboard**:
   - Executive header, official weather illustration (`weather_overview.jpg`), and rigorous problem statement.
   - Dataset quick profile (73.5 years, 26,803 records, 0 duplicate dates, class balance).
   - Real-time KPI cards: record count, rainy day volume, top model F1, and regressor $R^2$.
   - Interactive class distribution donut chart, monthly monsoon seasonality bar chart, and long-term temperature time-series.
2. **Data & EDA Overview**:
   - Full column metadata table with exact null counts, null percentages, unique counts, data types, and sample entries.
   - Descriptive statistical summary table (`.describe()`) covering all 8 numeric features.
   - Paginated dataset view formatted in **10 records per page** (2,681 total pages) with interactive page number selection and direct year-jump navigation.
   - One-click CSV export buttons for the current 10-row page and the top 5,000 records.
3. **Weather Prediction & Forecast (Unified Interface)**:
   - Interactive sliders for day $t$ observations: Temp Max, Temp Min, calculated Diurnal Range, Month, and Day.
   - Model selection dropdown: Random Forest, Decision Tree, or Logistic Regression.
   - Simultaneous generation of:
     - **Rainfall Prediction**: Class label (Rain / No Rain), rain probability %, dry probability %, and progress bar.
     - **Temperature Prediction**: Tomorrow's continuous maximum temperature in °C and thermal classification.
     - **Actionable Recommendations**: Umbrella advisory, clothing guidance across 5 thermal regimes, and outdoor activity feasibility index.
4. **Model Comparison & Objectives**:
   - **Objective 1**: Multi-variable Pearson correlation heatmap.
   - **Objective 2**: Combined multi-model ROC Curve with detailed analysis of TPR, FPR, and AUC values (Random Guess 0.5000, Logistic Regression 0.8407, Random Forest 0.8489, Decision Tree 0.8519).
   - **Objective 3**: Grouped performance metrics bar chart (Accuracy, Precision, Recall, F1, ROC-AUC) and comprehensive comparison table with dynamic metric ranking.
   - **Objective 4**: Confusion matrix heatmaps for all 3 classifiers with TP, FP, TN, and FN counts.
   - **Objective 5**: Temperature regression diagnostic scatter plot (Actual vs. Predicted 1:1 line) and residual error histogram.
5. **MongoDB Database Console**:
   - Real-time connection status monitor with ping verification.
   - Comprehensive 7-point classification of how and where PyMongo is implemented.
   - Ingestion trigger button executing idempotent bulk upsert of 26,803 records.
   - Live query console filtering documents by year with custom document limits.

---

## 7. MongoDB Architecture & PyMongo Classification

WeatherWise Analytics structures its MongoDB integration through seven distinct architectural roles:

1. **Client Pooling & CSOT (`pymongo.MongoClient`):**
   - Configured with `serverSelectionTimeoutMS=3000`, `connectTimeoutMS=3000`, and `socketTimeoutMS=3000`.
   - Managed as a cached singleton resource via `@st.cache_resource` in Streamlit.
2. **Diagnostic Health Ping (`client.admin.command('ping')`):**
   - Actively tests server connectivity prior to executing operations.
   - If unreachable, catches `ServerSelectionTimeoutError` and activates **Offline CSV Fallback Mode**.
3. **Deterministic Unique Indexing (`collection.create_index`):**
   - `idx_record_key_unique`: Enforces unique constraint on `Record_Key` (`YYYY-MM-DD`).
   - `idx_date_parsed`: Ascending index on BSON datetime for chronological range queries.
   - `idx_year_month`: Compound index on `(Year, Month)` for monthly aggregations.
4. **Idempotent Bulk Upsert Ingestion (`bulk_write` with `UpdateOne`):**
   - Batches records in chunks of 1,000 operations with `ordered=False`.
   - Query: `UpdateOne({'Record_Key': key}, {'$set': record_dict}, upsert=True)`.
   - Idempotent guarantee: Initial run inserts 26,803 documents; subsequent runs match 26,803 documents with 0 new insertions.
5. **Parameterized Querying & Projections (`collection.find`):**
   - Executes range queries with strict projections (excluding unnecessary BSON fields) to minimize network overhead.
6. **Telemetry & Collection Statistics (`count_documents` & `list_indexes`):**
   - Live document counting and index inspection.
7. **Destructive Operation Guardrails (`db.drop_collection`):**
   - Requires explicit programmatic confirmation (`confirm=True`) to prevent accidental data loss.

---

## 8. Troubleshooting & Diagnostic Guide

### Issue: `ServerSelectionTimeoutError: localhost:27017: [WinError 10061]`
- **Root Cause**: The local MongoDB service is stopped or not running on port 27017.
- **Fix**: Launch the MongoDB service or daemon:
  ```powershell
  # Start local MongoDB daemon
  mongod --dbpath "D:\mongodb\data\data" --port 27017
  ```
- *Note:* WeatherWise Analytics automatically operates in **Offline CSV Fallback Mode** if MongoDB is offline.

### Issue: Running Tests Uses Wrong Python Environment
- **Root Cause**: `pytest` on Windows PATH may point to an older Python installation.
- **Fix**: Run tests explicitly using the active Python executable:
  ```powershell
  python -m pytest tests/ -v
  ```

### Issue: Port 8501 Already in Use
- **Fix**: Launch Streamlit on an alternate port:
  ```powershell
  streamlit run app.py --server.port 8502
  ```

---

## 9. Viva & Presentation Summary

When presenting this project during a technical viva:

1. **Why Chronological Splitting instead of Random K-Fold?**:
   Weather observations are sequential time-series data. Random splitting allows observations from the future to leak into the past, artificially inflating evaluation metrics. Chronological splitting (training on 1951–2009 and testing on 2009–2024) provides an authentic, real-world forecast benchmark.
2. **Why Exclude Current-Day Rain from Features?**:
   If the model is asked to predict whether it will rain *tomorrow*, today's rain outcome or qualitative indicator could introduce target leakage if defined improperly. Excluding current rain indicators guarantees that the model learns purely from diurnal temperature ranges and seasonal patterns.
3. **Why Random Forest for the Final Recommendation Engine?**:
   Random Forest achieved the top F1 score (0.5476) and highest accuracy (76.56%), effectively filtering out false alarms. However, for applications where missing a rain event is catastrophic, Decision Tree provides the highest sensitivity (recall = 82.38%).
4. **How Does PyMongo Prevent Duplicate Records?**:
   Each document is assigned a deterministic `Record_Key` (`YYYY-MM-DD`). A unique index is placed on this field, and ingestion is executed via `UpdateOne(..., upsert=True)`. Repeated runs update or match existing records rather than inserting duplicate documents.
5. **How is Offline Resilience Achieved?**:
   `MongoDBManager.ping()` tests the connection with a 3-second timeout. If the server is offline, it raises no unhandled errors; instead, it sets `is_connected = False` and the app immediately uses `data/delhi_weather.csv` for 100% feature availability.
